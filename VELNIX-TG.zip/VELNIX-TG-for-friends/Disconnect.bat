@echo off
title VELNIX-TG — Отключение VPN
echo Отключаем VPN...

REM Отключаем WireGuard туннель
wireguard.exe /uninstalltunnelservice "%~dp0configs\tg.conf"

echo VPN отключен.
pause