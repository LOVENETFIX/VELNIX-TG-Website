@echo off
title VELNIX-TG — Подключение Telegram
echo Подключение VPN только для Telegram...

REM Путь к конфигу WireGuard
set CONFIG=%~dp0configs\tg.conf

REM Проверяем, существует ли конфиг
if not exist "%CONFIG%" (
    echo Конфиг для Telegram не найден! Положи tg.conf в папку configs
    pause
    exit /b
)

REM Подключаем WireGuard
echo Подключаем VPN...
wireguard.exe /installtunnelservice "%CONFIG%"

echo Готово! Telegram теперь идет через VPN.
pause