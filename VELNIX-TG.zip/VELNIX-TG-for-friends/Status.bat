@echo off
title VELNIX-TG — Статус VPN
echo Проверяем статус VPN...

REM Проверяем, активен ли туннель
wireguard.exe /status "%~dp0configs\tg.conf"

pause